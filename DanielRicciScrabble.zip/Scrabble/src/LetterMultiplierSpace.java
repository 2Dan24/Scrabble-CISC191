
public class LetterMultiplierSpace
{

}
