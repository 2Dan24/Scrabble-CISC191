
public class WordMultiplierSpace
{

}
